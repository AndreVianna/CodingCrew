import os
import sys
from os.path import expanduser
import uuid

from models.query import Query
from models.project_state import ProjectState

from utils.general import to_snake_case, is_linux
from utils.terminal.terminal import clear, set_style, write, write_line, read_line, read_text


def create(state: ProjectState) -> ProjectState:
    yes_no: str = ""
    clear()
    name = set_style("Project Builder", "yellow", styles=["bold"])
    write_line(f"Welcome to {name}.", styles=["bold"])
    write_line()
    write_line("Let's start by getting some basic information about the project.")
    while yes_no != "yes" and yes_no != "y":
        yes_no = "" # Reset the value of yes_no
        user_folder = expanduser("~") if is_linux else os.environ.get("USERPROFILE")
        folder_separator = "/" if is_linux else "\\"
        default_folder = f"{user_folder}{folder_separator}projects"
        project_id = uuid.uuid4()
        write("Please, enter the project name: ")
        project_name = read_line()
        write_line()

        formatted_default_folder = set_style(default_folder, "cyan")
        write_line(f"Please, enter the full path of the projects root folder (default: '{formatted_default_folder}'): ")
        base_folder = read_line()
        if not base_folder:
            base_folder = default_folder
        project_folder = (
            f"{base_folder}{folder_separator}{to_snake_case(project_name)}{folder_separator}{str(project_id).lower()}"
        )
        write_line()

        formatted_project_folder = set_style(project_folder, "cyan")
        write_line(f"Your project will be located at: '{formatted_project_folder}'.")
        write_line("Is that OK? ([Yes]/No/eXit): ")
        yes_no = read_line().lower()
        if yes_no == "exit" or yes_no == "x":
            sys.exit(0)
        if not yes_no:
            yes_no = "yes" # Default selection

    yes_no = ""
    project_description = ""
    while yes_no != "yes" and yes_no != "y":
        yes_no = ""
        write_line()
        write_line("Please provide a detailed description of the project:")
        project_description = read_text()
        write_line()
        write_line("Can we proceed to the analysis of the project description? ([Yes]/no/eXit): ")
        yes_no = read_line().lower()
        if yes_no == "exit" or yes_no == "x":
            sys.exit(0)
        if not yes_no:
            yes_no = "yes"

    os.makedirs(project_folder, exist_ok=True)
    write_line("Project folder created.")
    write_line("Let's proceed with the initial analysis.")

    result = {
        **state,
        "id": str(project_id),
        "name": project_name,
        "folder": project_folder,
        "description": [project_description],
        "queries": list[Query](),
        "status": "STARTED",
    }
    return result
